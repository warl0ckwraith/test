#coded by Sanidhya
#menu driven program for restaurant management



import time
import random
import os
global product_name
product_name=['Pizza(small)','Pizza(medium)','Pizza(large)','Special Pizza','Burger(medium)','Burger(large)','Sandwich',"Coffee","Cold Coffee",'Cold Drinks',"Extra_Cheeze"]
global product_price
product_price=[150,220,300,450,125,210,270,220,270,25,50]
global GST
GST=12
global sum
sum=0
global pnum
pnum=[]
global pquan
pquan=[]
global gtotal
gtotal=0
count=0
Addon=0
cn=0
def orderid():
    global order_id
    global order_no
    global order_time
    global collect_counter
    order_time=random.randint(1,30)   
    order_no=random.randint(100,500)
    order_id=2*random.randint(1369578,63782388)
    collect_counter=random.randint(1,5)
def only_product():
    print('ProductName')
    print("                               MAIN MENU               ")
    print("1.",product_name[0])
    print("2.",product_name[1])
    print("3.",product_name[2])
    print("4.",product_name[3])
    print("5.",product_name[4])
    print("6.",product_name[5])
    print("7.",product_name[6])
    print("                                   DRINKS                 ")
    print("8.",product_name[7])
    print("9.",product_name[8])
    print("10.",product_name[9])
    print("                                   ADD-ONS               ")
    print("11.",product_name[10])
def  greetings():
    global name
    print("\n\n\n\n\n\n\n\n\n\n\n\n\n")
    print("                                                                 ___________________________________________________________________________                                                             ")
    print("                                                                 ___________________________________________________________________________                                                             ")
    name=input('\n                                                                                                    Enter Your Name>>')
    print('\n\n                                                                                                                      Hello' ,name)
    print('                                                                                                        Welcome to our Restaurant                         ')
    print("                                                                 ___________________________________________________________________________                                                             ")
    print("                                                                 ___________________________________________________________________________                                                             ")
def product():
    print('ProductName                                ProductRate(Without GST)')
    print("                               MAIN MENU               ")
    print("1.",product_name[0],"                                 Rs.",product_price[0])
    print("2.",product_name[1],"                            Rs.",product_price[1])
    print("3.",product_name[2],"                                 Rs.",product_price[2])
    print("4.",product_name[3],"                               Rs.",product_price[3])
    print("5.",product_name[4],"                         Rs.",product_price[4])
    print("6.",product_name[5],"                              Rs.",product_price[5])
    print("7.",product_name[6],"                                    Rs.",product_price[6])
    print("                                   DRINKS                 ")
    print("8.",product_name[7],"                                          Rs.",product_price[7])
    print("9.",product_name[8],"                                 Rs.",product_price[8])
    print("10.",product_name[9],"                               Rs.",product_price[9])
    print("                                   ADD-ONS               ")
    print("11.",product_name[10],"                           Rs.",product_price[10])
def pre_bill():
    os.system('cls')
    print('                 \n\n\n                                                                        Hello    ',name)
    print('\n\n\n\n\n\n\n\n\n\n\n                                                  Fetching your bill ........................................')
    time.sleep(2)
    os.system('cls')
    print('\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                     ==========..............................25%')
    time.sleep(1)
    os.system('cls')
    print('\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                     ====================....................50%')
    time.sleep(1)
    os.system('cls')
    print('\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                     ==============================..........75%')
    time.sleep(1)
    os.system('cls')	
    print('\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                     ========================================100%')
    os.system('cls')
    print('Your bill is successfully fetched....')
    time.sleep(1)
    os.system('cls') 
def tip():
    a=input('Do you want to add Tip(Y/N):')
    while a=='Y' or a=='y' or a=='N' or a=='n':
        if a=='Y' or a=='y' :
            t=int(input('Enter Amount:'))
            print('\n\n             Thank You')
            return t
        elif a=='N' or a=='n':
            print('OK')
            return 0
        else:
            print("Wrong input , Please try again ")
            a=input('Do you want to add Tip(Y/N):')
def extra(x):
    global Addon
    a=input('Do you want to add extra cheese(Y/N):')
    while a=='Y' or a=='y' or a=='N' or a=='n':
        if a=='Y' or a=='y' :
            Addon+=x
            return Addon
        elif a=='N' or a=='n':
            print('OK')
            return 0
        else:
            print("Wrong input , Please try again")
            a=input('Do you want to add extra cheese(Y/N):')
def thank():
    print('             \n\n\n   Thank You ',name)
    time.sleep(3)
def acpt():
    global count
    z=input("Do you want to order Food items(Y/N):")
    if z=='Y' or z=='y':
        os.system('cls')
        while z=='Y' or z=='y':
            print("****************************************Order Food & Drinks**********************************************")
            product()
            a=int(input('Enter the item no. which you want to order:'))
            if a==1:
                length=pnum.count(0)
                print('You have choosen Pizza(small)')
                if length>0:
                        n=int(input('Enter quantity  of pizza(small) you want to order  :  '))
                        extra(n)
                        k=pnum.index(0)
                        c=pquan[k]
                        pquan.insert(k,n+c)
                else:
                    pnum.insert(count,0)          
                    n=int(input('Enter quantity  of pizza(small) you want to order  :  '))
                    extra(n)
                    pquan.insert(count,n)
                count=count+1
            elif a==2:
                length=pnum.count(1)
                print('You have choosen Pizza(medium)')
                if length>0:
                        n=int(input('Enter quantity  of pizza(medium) you want to order  :  '))
                        extra(n)
                        k=pnum.index(1)
                        c=pquan[k]
                        pquan.insert(k,n+c)
                else:
                    pnum.insert(count,1)          
                    n=int(input('Enter quantity  of pizza(medium) you want to order  :  '))
                    extra(n)
                    pquan.insert(count,n)
                count=count+1
            elif a==3:
                length=pnum.count(2)
                print('You have choosen Pizza(large)')
                if length>0:
                        n=int(input('Enter quantity  of pizza(large) you want to order  :  '))
                        extra(n)
                        k=pnum.index(2)
                        c=pquan[k]
                        pquan.insert(k,n+c)
                else:
                    pnum.insert(count,2)          
                    n=int(input('Enter quantity  of pizza(large) you want to order  :  '))
                    extra(n)
                    pquan.insert(count,n)
                count=count+1
            elif a==4:
                length=pnum.count(3)
                print('You have choosen Special Pizza')
                if length>0:
                        n=int(input('Enter quantity  of Special Pizza you want to order  :  '))
                        extra(n)
                        k=pnum.index(3)
                        c=pquan[k]
                        pquan.insert(k,n+c)
                else:
                    pnum.insert(count,3)          
                    n=int(input('Enter quantity  of Special Pizza you want to order  :  '))
                    extra(n)
                    pquan.insert(count,n)
                count=count+1
            elif a==5:
                length=pnum.count(4)
                print('You have choosen Burger(medium)')
                if length>0:
                        n=int(input('Enter quantity  of Burger(medium) you want to order  :  '))
                        extra(n)
                        k=pnum.index(4)
                        c=pquan[k]
                        pquan.insert(k,n+c)
                else:
                    pnum.insert(count,4)          
                    n=int(input('Enter quantity  of Burger(medium) you want to order  :  '))
                    extra(n)
                    pquan.insert(count,n)
                count=count+1
            elif a==6:
                length=pnum.count(5)
                print('You have choosen Burger(large)')
                if length>0:
                        n=int(input('Enter quantity  of Burger(large) you want to order  :  '))
                        extra(n)
                        k=pnum.index(5)
                        c=pquan[k]
                        pquan.insert(k,n+c)
                else:
                    pnum.insert(count,5)          
                    n=int(input('Enter quantity  of Burger(large) you want to order  :  '))
                    extra(n)
                    pquan.insert(count,n)
                count=count+1
            elif a==7:
                length=pnum.count(6)
                print('You have choosen Sandwich')
                if length>0:
                        n=int(input('Enter quantity of Sandwich you want to order  :  '))
                        extra(n)
                        k=pnum.index(6)
                        c=pquan[k]
                        pquan.insert(k,n+c)
                else:
                    pnum.insert(count,6)          
                    n=int(input('Enter quantity of Sandwich you want to order  :  '))
                    extra(n)
                    pquan.insert(count,n)
                count=count+1
            elif a==8:
                length=pnum.count(7)
                print('You have choosen Coffee')
                if length>0:
                        n=int(input('Enter quantity of Coffee you want to order  :  '))
                        k=pnum.index(7)
                        c=pquan[k]
                        pquan.insert(k,n+c)
                else:
                    pnum.insert(count,7)          
                    n=int(input('Enter quantity of Coffee you want to order  :  '))
                    pquan.insert(count,n)
                count=count+1
            elif a==9:
               length=pnum.count(8)
               print('You have choosen Cold Coffee')
               if length>0:
                    n=int(input('Enter quantity of Cold Coffee you want to order  :  '))
                    k=pnum.index(8)
                    c=pquan[k]
                    pquan.insert(k,n+c)
               else:
                    pnum.insert(count,8)          
                    n=int(input('Enter quantity of Cold Coffee you want to order  :  '))
                    pquan.insert(count,n)
                    count=count+1
            elif a==10:
                length=pnum.count(9)
                print('You have choosen Cold Drink')
                if length>0:
                    n=int(input('Enter quantity of Cold Drink you want to order  :  '))
                    k=pnum.index(9)
                    c=pquan[k]
                    pquan.insert(k,n+c)
                else:
                    pnum.insert(count,9)          
                    n=int(input('Enter quantity of Cold Drink you want to order  :  '))
                    pquan.insert(count,n)
                count=count+1
            elif a==11:
                print("Can only be ordered if you order items b/w No.1 - NO.7")
            else:
                print("Wrong Input")
                acpt()
            z=input('Do you want to order more food(Y/N):')
        else:
            if count==0:
                print('\n\nYou did not ordered any items ')
                print('Returning back for menu')
                time.sleep(1.5)
            else:
                print('\n\n              Your order is accepted')
                time.sleep(1)
        return count
    else:
        os.system('cls')
        menu()      
def id(x,y,z,w):
    a=count
    if a==0:
        print('You have ordered 0 items')
        time.sleep(1.5)
        os.system('cls')
        menu()
    else:
        print('Your order ID:',x,'Save it for future reference')
        print('\n\n Your order is under queue , to be proccessed soon')
        print('\n\nYour order no.:',y)
        if z==0:
            print("\n\nYour order is ready please collect it from counter ",w)
        else:
            print('\n\nAfter ',z,' Minutes your order will be ready and you can take it from counter')
        In=input("\n\n\nPRESS (B) TO GET BACK TO MAIN MENU:")
        while In=='B' or In=='b':
            if In=='B' or In=='b':
                os.system('cls')
                menu()
            else:
                print("Wrong Input , Please Try again")
                time.sleep(2)
                In=input("\n\n\nPRESS (B) TO GET BACK TO MAIN MENU:")
            id()
def info():
    os.system('cls')
    only_product()
    print()
    i=int(input('\nEnter product no. :'))
    if i==1:
        os.system('cls')
        print("-----------------------------------------------------------------------------------------------------------------------")
        print('\n        Pizza(small) ~ Its a pizza of radius 5 cm with no toppings')
        print("-----------------------------------------------------------------------------------------------------------------------")
    elif i==2:
        os.system('cls')
        print("--------------------------------------------------------------------------------------------------------------------------------------------------------------------")
        print('\n       Pizza(medium) ~ Its a pizza of radius 8 cm with some cheese and sweet corn on it')
        print("--------------------------------------------------------------------------------------------------------------------------------------------------------------------")
    elif i==3:
        os.system('cls')
        print("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
        print('\n       Pizza(large) ~ Its a pizza of radius 13 cm with topping like cheese,paneer,sweet corn , margreta etc.')
        print("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
    elif i==4:
        os.system('cls')
        print("--------------------------------------------------------------------------------------")
        print('\n      Pizza(Special) ~ It is our special pizza')
        print("--------------------------------------------------------------------------------------")
    elif i==5:
        os.system('cls')
        print("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
        print('\n      Burger(medium) ~ Its a small burger with cheese, aloo tikki and some vegetables inside')
        print("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
    elif i==6:
        os.system('cls')
        print("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
        print('\n        Burger(large) ~ Its a large burger with cheese, Mayonnaise,aloo tikki, vegetables and chowmins inside ')
        print("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
    elif i==7:
        print("----------------------------------------------------------------------------------------------------------------------------------------------------------------")
        print('\n          Sandwich ~ Its a normal sandwich with some cheese and vegetables in it  ')
        print("----------------------------------------------------------------------------------------------------------------------------------------------------------------")
    elif i==8:
        os.system('cls')
        print("-------------------------------------------------------------------------------------------------------------------")
        print('\n        Cold Coffee ~ Its a cold coffee with ice cream in it.')
        print("-------------------------------------------------------------------------------------------------------------------")
    elif i==9:
        os.system('cls')
        print("---------------------------------------------------------------------------------------------------")
        print('\n       Coffee ~ Its a coffee with hot chocolate on it')
        print("---------------------------------------------------------------------------------------------------")
    elif i==10:
        os.system('cls')
        print("----------------------------------------------------------------------------------------------------------------")
        print('\n           Cold Drink ~ It is a cold drink bottle of 250 ml')
        print("----------------------------------------------------------------------------------------------------------------")
    elif i==11:
        os.system('cls')
        print("--------------------------------------------------------------")
        print('\n       Extra Cheese Topping')
        print("--------------------------------------------------------------")
    else :
        os.system('cls')
        print('Wrong input')
        info()
def bill():
    if count==0:
        os.system('cls')
        print('You have ordered 0 items')
        time.sleep(1)
        In=input("\n\n\nPRESS (B) TO GET BACK TO MAIN MENU:")
        while In=='B' or In=='b':
            if In=='B' or In=='b':
                os.system('cls')
                menu()
            else:
                print("Wrong Input , Please Try again")
                time.sleep(2)
                In=input("\n\n\nPRESS (B) TO GET BACK TO MAIN MENU:")
    else:
        global gsum
        gsum=0
        pre_bill()
        Tip=tip()
        print(pnum)
        print("\n\n                                                             Your Restraunt                                                  ")
        print("\n                                             XYZ,ABC Road,Jhotwara,Jaipur-302012                                             ")
        print("                                                       98833-xxxxx,83884-xxxxx                                                   ")
        print("\nGSTIN:88304XJ2882S82                                           ")
        print("\n                                                                 GST INVOICE                                                                  ")
        print("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
        print("                                                             Customer Name:",name)
        print("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
        print("ProductName               Qty.                 Rate(Inclusive GST)                   Amount                  GST(%)")
        print("--------------------------            ----------               --------------------------------------                 ----------------                ---------------")
        for i in range (0,len(pnum)):
            if pnum[i]==0:
                rate=product_price[0]+(product_price[0]*(12/100))
                gsum=+(rate*pquan[i])
                print(product_name[0],end='');print("                   ",pquan[i],end='');print("                                    ",rate,end='',);print("                            ",rate*pquan[i],end='');print("                     ",GST,"%")
            elif pnum[i]==1:
                rate=product_price[1]+(product_price[1]*(12/100))
                gsum=gsum+(rate*pquan[i])
                print(product_name[1],end='');print("              ",pquan[i],end='');print("                                    ",rate,end='',);print("                                ",rate*pquan[i],end='');print("                         ",GST,"%")
            elif pnum[i]==2:
                rate=product_price[2]+(product_price[2]*(12/100))
                gsum=gsum+(rate*pquan[i])
                print(product_name[2],end='');print("                   ",pquan[i],end='');print("                                    ",rate,end='',);print("                       ",rate*pquan[i],end='');print("                    ",GST,"%")
            elif pnum[i]==3:
                rate=product_price[3]+(product_price[3]*(12/100))
                gsum=gsum+(rate*pquan[i])
                print(product_name[3],end='');print("                 ",pquan[i],end='');print("                                    ",rate,end='',);print("                               ",rate*pquan[i],end='');print("                    ",GST,"%")
            elif pnum[i]==4:
                rate=product_price[4]+(product_price[4]*(12/100))
                gsum=gsum+(rate*pquan[i])
                print(product_name[4],end='');print("            ",pquan[i],end='');print("                                     ",rate,end='',);print("                        ",rate*pquan[i],end='');print("                     ",GST,"%")
            elif pnum[i]==5:
                rate=product_price[5]+(product_price[5]*(12/100))
                gsum=gsum+(rate*pquan[i])
                print(product_name[5],end='');print("                   ",pquan[i],end='');print("                                     ",rate,end='',);print("                              ",rate*pquan[i],end='');print("                  ",GST,"%")
            elif pnum[i]==6:
                rate=product_price[6]+(product_price[6]*(12/100))
                gsum=gsum+(rate*pquan[i])
                print(product_name[6],end='');print("                 ",pquan[i],end='');print("                                ",rate,end='',);print("                              ",rate*pquan[i],end='');print("              ",GST,"%")         
            elif pnum[i]==7:
                rate=product_price[7]+(product_price[7]*(12/100))
                gsum=gsum+(rate*pquan[i])
                print(product_name[7],end='');print("                     ",pquan[i],end='');print("                                     ",rate,end='',);print("                               ",rate*pquan[i],end='');print("                   ",GST,"%")
            elif pnum[i]==8:
                rate=product_price[8]+(product_price[8]*(12/100))
                gsum=gsum+(rate*pquan[i])
                print(product_name[8],end='');print("                    ",pquan[i],end='');print("                                    ",rate,end='',);print("                                 ",rate*pquan[i],end='');print("                    ",GST,"%")
            else:
                rate=product_price[9]+(product_price[9]*(12/100))
                gsum=gsum+(rate*pquan[i])
                print(product_name[9],end='');print("                    ",pquan[i],end='');print("                                      ",rate,end='',);print("                              ",rate*pquan[i],end='');print("                   ",GST,"%")
        if Addon>0:
            rate=product_price[10]+(product_price[10]*(12/100))
            print(product_name[10],end='');print("               ",Addon,end='');print("                                      ",rate,end='',);print("                              ",rate*pquan[i],end='');print("                      ",GST,"%")
        print("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
        GrandTotal=gsum+(50+(50*(12/100)))*Addon
        GTR=round(GrandTotal,2)
        print("                                                                                                                                        GRAND TOTAL:",GTR)
        print("                                                                                                                                         +Tip : Rs.",Tip)
        thank()
        In=input("\n\n\nPRESS (B) TO GET BACK TO MAIN MENU:")
        while In=='B' or In=='b':
            if In=='B' or In=='b':
                return gsum
                os.system('cls')
                menu()
            else:
                print("Wrong Input , Please Try again")
                time.sleep(2)
                In=input("\n\n\nPRESS (B) TO GET BACK TO MAIN MENU:")
            
def menu():
    a=int(input('\n\n\nEnter Your choice :\n1.Menu\n2.Information About Food Items\n3.Order Food Items\n4.Fetch Bill\n5.Order Id & Status\n6.Feedback\n7.Exit\nIn[ ]:'))
    if a==1:
        print("                 \n\n\n***************************Food Menu*****************************\n                 ")
        product()
        In=input("\n\n\nPRESS (B) TO GET BACK TO MAIN MENU:")
        while In=='B' or In=='b':
            if In=='B' or In=='b':
                os.system('cls')
                menu()
            else:
                print("Wrong Input , Please Try again")
                time.sleep(2)
                In=input("\n\n\nPRESS (B) TO GET BACK TO MAIN MENU:")
    elif a==2:
        val=input('\n\n\n\n\n           Do you want to see information about food items(Y/N):')
        while val=="Y" or val=='y' :
            print(val)
            os.system('cls')
            info()
            val=input('\n\n\n\n\n           Do you want more information about food items(Y/N):')
        else:
            os.system('cls')
    elif a==3:
        os.system('cls')
        acpt()
        os.system('cls')
    elif a==4:
        os.system('cls')
        bill()
        os.system('cls')
    elif a==5:
        global cn
        global order_time
        if cn>0 and order_time>0 :
            order_time=order_time-random.randint(1,order_time)
        cn+=1
        id(order_id,order_no,order_time,collect_counter)
        os.system('cls')
        menu()
    elif a==6:
        feedback()
    elif a==7:
        print("Have a Good Day")
    else:
        print("Wrong input")
        menu()
def feedback():
    os.system('cls')
    feed=input('Please Provide us your valuable feedback : ')
    print("\n\nYour provided feedback : ",feed)
    i=input('\n\nWould you like to edit your feedback (Y/N) :')
    if i=='y' or i=='Y':
        while i=='Y' or 'y':
            feed=input('\nPlease Provide us your valuable feedback : ')
            i=input('\n\nWould you like to edit your feedback (Y/N) :')
            if i=='N' or i=='n':
                 print("\n\nThank You")
                 time.sleep(1)
                 os.system('cls')
                 menu()
    elif i=='N' or i=='n':
        print("\n\nThank You")
        time.sleep(1)
        os.system('cls')
        menu()
    else:
        print("\nWrong Input , Please Try again")
        feedback()
def main():
    greetings()
    orderid()
    menu()
main()
print(time.time)
time.sleep(1)
