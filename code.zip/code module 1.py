#coded by Sanidhya
#menu driven program for restaurant management
import time
import random
import os
global product_name
product_name=['Pizza(small)','Pizza(medium)','Pizza(large)','Special Pizza','Burger(medium)','Burger(large)','Coffee','Sandwich','Cold Drinks']
global product_price
product_price=[150,220,300,450,125,210,270,220,100,25]
global GST
GST=12
def  greetings():
    global name
    name=input('Enter Your Name:')
    print('Hello' ,name)
    print('Welcome to our Restaurant')
def product():
    print('ProductName                              ProductPrice')
    print("1.",product_name[0],"                             ",product_price[0])
    print("2.",product_name[1],"                           ",product_price[1])
    print("3.",product_name[2],"                             ",product_price[2])
    print("4.",product_name[3],"                            ",product_price[3])
    print("5.",product_name[4],"                          ",product_price[4])
    print("6.",product_name[5],"                            ",product_price[5])
    print("7.",product_name[6],"                             ",product_price[6])
    print("8.",product_name[7],"                                ",product_price[7])
    print("9.",product_name[8],"                               ",product_price[8])
    print("10.",product_name[9],"                             ",product_price[9])
def tip():
    a=input('Do you want to add Tip(Y/N):')
    if a=='Y' or a=='y' :
        t=int(input('Enter Amount:'))
        print('\n\n             Thank You')
        return t
    elif a=='N' or a=='n':
        print('\n\n                     Its Ok ')
        return 0
    else:
        print('Wrong Input')
        tip()
def extra():
    a=input('Do you want to add extra cheese(Y/N):')
    if a=='Y' or a=='y' :
        e=50
        return e
    elif a=='N' or a=='n':
        print('OK')
        return 0
    else:
        print("Wrong input")
        extra()
def thank():
    print('             \n\n\n   Thank You ',name)
    time.sleep(3)
def acpt():
    global price
    price=0
    global count
    count=0
    i=input("Do you want to order Food items(Y/N):")
    while i=='Y' or i=='y':
        product()
        a=int(input('Enter the item no. which you want to order:'))
        if a==1:
            print('You have choosen Pizza(small)')
            n=int(input('Enter quantity  of pizza(small) you want to order  :  '))
            e=extra()
            price=150*n+e*n+price
        elif a==2:
            print('You have choosen Pizza(medium)')
            n=int(input('Enter quantity of pizza(medium) you want to order:'))
            e=extra()
            price=220*n+e*n+price
        elif a==3:
            print('You have choosen Pizza(large)')
            n=int(input('Enter quantity  of pizza(large)) you want to order:'))
            e=extra()
            price=300*n+e*n+price
        elif a==4:
            print('You have choosen Special Pizza ')
            n=int(input('Enter quantity  of Special Pizza you want to order:'))
            e=extra()
            price=450*n+e*n+price
        elif a==5:
            print('You have choosen Burger(medium)')
            n=int(input('Enter quantity  of Burger(medium) you want to order:'))
            e=extra()
            price=125*n+e*n+price
        elif a==6:
            print('You have choosen Burger(large)')
            n=int(input('Enter quantity  of Burger(large) you want to order:'))
            e=extra()
            price=210*n+e*n+price
        elif a==7:
            print('You have choosen Coffee')
            n=int(input('Enter quantity  of Coffee you want to order:'))
            price=270*n+price
        elif a==8:
            print('You have choosen Cold Coffee')
            n=int(input('Enter quantity  of Cold Coffee you want to order:'))
            price=220*n+price
        elif a==9:
            print('You have choosen Sandwich')
            n=int(input('Enter quantity  of Sandwiches you want to order:'))
            e=extra()
            price=100*n+e*n+price
        elif a==10:
            print('You have choosen Cold Drink')
            n=int(input('Enter quantity  of Cold Drinks you want to order:'))
            price=25*n+price 
        else:
            print("Wrong Input")
            count=count+1
            i=input('Do you want to order more food(Y/N):')
    else:
        if count==0:
            print('\n\nYou did not ordered any items ')
            print('Returning back for menu')
            time.sleep(1.5)
        else:
            print('\n\n              Your order is accepted')
            time.sleep(1)
def info():
    a=input('Do you want to see information about food items(Y/N):')
    if a=='Y' or a=='y' :
        product()
        print()
        i=int(input('Enter product no. :'))
        if i==1:
            print('Its a pizza of radius 15 cm with no toppings')
        elif i==2:
            print('Its a pizza of radius 20 cm with some cheese and sweet corn on it')
        elif i==3:
            print('Its a pizza of radius 25 cm with topping like cheese,paneer,sweet corn , margreta etc.')
        elif i==4:
            print('It is our special pizza')
        elif i==5:
            print('Its a small burger with cheese, aloo tikki and some vegetables inside')
        elif i==6:
            print('Its a large burger with cheese, Mayonnaise,aloo tikki, vegetables and chowmins inside ')
        elif i==7:
            print('Its a coffee with hot chocolate on it ')
        elif i==8:
            print('Its a cold coffee with ice cream in it ')
        elif i==9:
            print('Its a normal sandwich with some cheese and vegetables in it ')
        elif i==10:
            print('It is a cold drink bottle of 250 ml')
        else :
            print('Wrong input')
            info()
    elif a=='N' or a=='n':
        print()
    else:
        print("Wrong Input try again")
        info()
def bill():
    amt=price+price*(18/100)
    t=tip()
    tbill=t+amt
    print('                 \n\n\n                   Hello               ')
    print('Fetching your bill ........................................')
    time.sleep(2)
    os.system('cls')
    print('==========..............................25%')
    time.sleep(1)
    os.system('cls')
    print('====================....................50%')
    time.sleep(1)
    os.system('cls')
    print('==============================..........75%')
    time.sleep(1)
    os.system('cls')	
    print('========================================100%')
    time.sleep(1)
    os.system('cls') 
    print('Your bill is successfully fetched....')
    print('\n\n         You have ordered',count,' type of food items\n')
    print('Your bill ')
    print('Total Amount :  Rs.',tbill)
    thank()
    time.sleep(1.5)
def menu():
    a=int(input('\n\n\nEnter Your choice :\n1.Menu\n2.Information About Food Items\n3.Order Food Items\n4.Fetch Bill\n5.Order Status\n6.Exit\nIn[ ]:'))
    if a==1:
        print("                 \n\n\n The menu is :\n                 ")
        product()
        time.sleep(4)
        os.system('cls')
        menu()
    elif a==2:
        print("             \n\n\nThe information is :\n           ")
        info()
        menu()
    elif a==3:
        acpt()
        os.system('cls')
        menu()
    elif a==4:
        id()
        bill()
        os.system('cls')
        menu()
    elif a==6:
        print()
    elif a==5:
        id()
        os.system('cls')
        menu()
    else:
        print("Wrong input")
        menu()
def id():
    a=count
    if a==0:
        print('You have ordered 0 items')
        time.sleep(1.5)
        os.system('cls')
        menu()
    else:
        print('Your order ID:',2*random.randint(136958,6378288),'Save it for future reference')
        print('\n\n           Your order is under queue and to be proccessed soon')
        print('Your order no.:',random.randint(100,500))
        print('\n\nAfter ',random.randint(1,30),' Minutes your order will be ready and delievered to your table')
        time.sleep(6)
        os.system('cls')
        menu()
def main():
    greetings()
    menu()
main()