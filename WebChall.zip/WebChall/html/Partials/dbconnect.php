<?php
$username="root";
$password="root";
$db="users";
$server="localhost";
$conn=mysqli_connect($server,$username,$password,$db);
if($conn){
}
 else{
    die("Error ". mysqli_connect_error());
}

?>
