<?php
$success=false;  
$uval=false;
$pval=false;
include 'Partials/dbconnect.php';
function user_val($user,$conn)
{
  $query="select username from users where username='$user'";
  $insert=mysqli_query($conn,$query);
  $row=mysqli_num_rows($insert);
  return $row;
}
function pass_val($pass,$cpass)
{
  if($pass==$cpass)
  {
  return true;
  }
}
if($_SERVER['REQUEST_METHOD']=="POST")
{
  $username=$_POST['username'];
  $password=$_POST['password'];
  $cpassword=$_POST['cpassword'];
  $uval=user_val($username,$conn);
  $pval=pass_val($password,$cpassword);
  if(!$uval)
  {
    if($pval)
    {
      $hash=password_hash($password,PASSWORD_DEFAULT);
      $query="insert into users(username,password) values('$username','$hash')";
      $insert=mysqli_query($conn,$query);
      if ($insert)
      {
        $success=true;
      } 
    }
  }
}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Sign-Up</title>
  </head>
  <body> 
      <?php require 'Partials/_nav.php'?>
      <?php
      if($success){
      echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Success! Account Created. </strong>Proceed with login page.
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';}
      if($uval){
      echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Username exists already </strong>.Please provide another username.
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';}
      if(!$pval){
  echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
<strong>Passwords Mismatch! </strong>Check Passwords
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';}
      ?>

    <div class="container">
    <h1 class="text-center">Sign-Up to our Website</h1>
    <form action="signup.php" method="POST">
  <div class="mb-3">
    <label for="username" class="form-label">Username</label>
    <input type="text" class="form-control" id="username" name="username" maxlength=20>
  <div class="mb-3">
    <label for="password" class="form-label">Password</label>
    <input type="password" class="form-control" id="password" name="password" maxlength=30>
  </div>
  <div class="mb-3">
    <label for="cpassword" class="form-label">Confirm Password</label>
    <input type="password" class="form-control" id="cpassword" name="cpassword" maxlength=30>
  </div>
  <button type="submit" class="btn btn-primary">Signup</button>
</form>

    </div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>
