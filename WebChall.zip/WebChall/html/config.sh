#!/bin/bash
sudo a2enmod dav dav_fs
sudo echo "Dav On" >> /etc/apache2/sites-available/default
sudo echo "DavFSMethod PUT" >> /etc/apache2/sites-available/default 



