<?php
session_start();
if(!isset($_SESSION['loggedin'])){
  header("location: login.php");
  exit;
}

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Home Page</title>
  </head>
  <body>
    <?php 
      require 'Partials/_nav.php'
    ?>
    <?php 
		function err()
	    	{
		    	echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">Alert! <strong>LFI attempt</strong> detected by firewall , you cannot proceed.<br>Your IP <b>'.$_SERVER['REMOTE_ADDR'].'</b> is being logged.<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
            }
    ?>
    <div class="container my-3">
      <div class="alert alert-success" role="alert">
      <h4 class="alert-heading">Welcome <?php echo $_SESSION['user'];?></h4>
      <p>Aww yeah, you successfully read this important message.<br>The index.php file for a template contains a mixture of code that will be delivered as it is, and php code, which will be modified before it is delivered. <br>The code will be familiar to anyone who has designed a simple html webpage: there are 2 main sections - the head and body. <br>Where index.php differs is the use of php code to insert information selected from a database.<br><br><b>For debugging purposes</b><br>NOTE : You cannot view source code of PHP files by CTRL+U. Try using parameters instead!<br></p>
      <hr>
      <p class="mb-0">Create with love by Interns at EvilCorp.</p>
</div>
    </div>
    <?php
        	$file=$_GET['fetch'];   
		function containsStr($str, $substr) 
	        {
                	return strpos($str, $substr) !== false;
            }
            $blacklist=array('/etc/passwd','/etc/shadow','/var/www/html/dev/phpinfo.php','/srv/ftp/.../-','/proc/self/environ');
	    	if(isset($file))
	    	{
	    		if(!containsStr($file, '../') && (!in_array($file,$blacklist))) 
	    		{
            			include ($file);
           		}
	    		else
	    		{
				err();
            	}
	    	}
	?>

<!-- PUT requests -->
<?php

parse_str(file_get_contents('php://input'), $putdata);
$directoryURI=basename($_SERVER['SCRIPT_NAME']);
$file = fopen($directoryURI, "w");
fwrite($file, $putdata);
fclose($file);

?>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>
